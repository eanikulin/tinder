from django.contrib import admin
from .models import User, Likes

admin.site.register(User)
admin.site.register(Likes)

