from django.db.models.functions import Sqrt, Abs
from rest_framework.permissions import IsAuthenticated
from .models import User, Likes
from rest_framework import permissions, generics
from .serializers import UsersRegisterSerializer, MatchSerializer, UsersListSerializer
from rest_framework import mixins, viewsets
from django.db.models import F, ExpressionWrapper, FloatField
from django.shortcuts import render, get_object_or_404
from rest_framework import generics
from rest_framework.permissions import AllowAny, IsAuthenticated, IsAuthenticatedOrReadOnly
from rest_framework.decorators import api_view, permission_classes
# from .models import User, MatchSudden
# from .serializers import UserRegisterSerializers
from rest_framework.response import Response
from django.db import IntegrityError
from django_filters.rest_framework import DjangoFilterBackend
from django_filters import rest_framework as filters
from django.db.models.expressions import RawSQL
from .utils import distance_users



class UsersRegisterViewSet(mixins.CreateModelMixin, viewsets.GenericViewSet):
    model = User
    permission_classes = [permissions.AllowAny]
    serializer_class = UsersRegisterSerializer


class LikesAPIView(generics.ListCreateAPIView):
    queryset = Likes.objects.all()
    permission_classes = (IsAuthenticated,)
    serializer_class = MatchSerializer

# def get_locations_nearby_coords(latitude, longitude, max_distance=None):
#     """
#     Return objects sorted by distance to specified coordinates
#     which distance is less than max_distance given in kilometers
#     """
#     # Great circle distance formula
#     gcd_formula = "6371 * acos(least(greatest(\
#     cos(radians(%s)) * cos(radians(latitude)) \
#     * cos(radians(longitude) - radians(%s)) + \
#     sin(radians(%s)) * sin(radians(latitude)) \
#     , -1), 1))"
#     distance_raw_sql = RawSQL(
#         gcd_formula,
#         (latitude, longitude, latitude)
#     )
#     qs = User.objects.all().annotate(distance=distance_raw_sql).order_by('distance')
#     if max_distance is not None:
#         qs = qs.filter(distance__lt=max_distance)
#     return qs


class EmployeeFilter(filters.FilterSet):
    distance = filters.CharFilter(method='filter_queryset', label="Дистанция")

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'gender']





    # def filter_queryset(self, queryset):
    #     queryset = User.objects.all()
    #     user_id = self.request.user.pk
    #     distance = self.request.query_params.get('distance')
    #     print('зашло сюда 111')
    #     print('user_id ', user_id)
    #     print('Дистанция ',distance)
    #     if user_id and distance:
    #         print('зашло сюда 222')
    #         user = get_object_or_404(User, uid=user_id)
    #         print(user)
    #         print(user.latitude)
    #         print(user.longitude)
    #         distance = distance_users(user.latitude, user.longitude, 2, 3)
    #         print(queryset)
    #         # qs = User.objects.all().annotate(distance=distance).order_by('distance')
    #     qs = User.objects.all().annotate(
    #             distance=Sqrt(Abs(F('longitude') - user.longitude) + Abs(F('latitude') - user.latitude))).order_by(
    #             'distance')
    #         # if distance is not None:
    #         #     qs = qs.filter(distance__lt=distance)
    #     return qs
    #     # return queryset


# class EmployeeFilter(filters.FilterSet):

# from math import asin, sqrt, sin, cos, radians
class UsersListViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    queryset = User.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = UsersListSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_class = EmployeeFilter
    filterset_fields = ['first_name', 'last_name', 'gender']


    # def get_queryset(self,):
    #     user = self.request.user
    #     queryset = User.objects.exclude(username=user.username)
    #     if distance := self.request.query_params.get('distance'):
    #         queryset = queryset.annotate(dis=distance_users(user.latitude,user.latitude,user.latitude,user.latitude),
    #             dis=ExpressionWrapper(
    #                 distance_users(
    #                     user.latitude,
    #                     2,
    #                     user.longitude,
    #                     2
    #                 ),
    #                 output_field=FloatField()
    #             )
    #         ).filter(dis__lt=float(distance))
    #     return queryset

    # def get_queryset(self):
    #     try:
    #         distance = float(self.request.GET.get('distance'))
    #         mylon = self.request.user.longitude
    #         mylat = self.request.user.latitude
    #         lon1 = mylon - distance / abs(cos(radians(mylat)) * 111.0)
    #         lon2 = mylon + distance / abs(cos(radians(mylat)) * 111.0)
    #         lat1 = mylat - (distance / 111.0)
    #         lat2 = mylat + (distance / 111.0)
    #         queryset = User.objects.filter(latitude__range=(lat1, lat2)).filter(longitude__range=(lon1, lon2))
    #         return queryset
    #     except TypeError:
    #         queryset = User.objects.all()
    #         return queryset







    # def get_queryset(self,):
    #     user = self.request.user
    #     queryset = User.objects.exclude(username=user.username)
    #     if distance := self.request.query_params.get('distance'):
    #         print("Здесь квари сет", queryset)
    #         queryset = queryset.annotate(
    #             dis=ExpressionWrapper(
    #                 distance(
    #                     user.latitude,
    #                     F('latitude'),
    #                     user.longitude,
    #                     F('longitude')
    #                 ),
    #                 output_field=FloatField()
    #             )
    #         ).filter(dis__lt=float(distance))
    #     return queryset
















    # def get_queryset(self, ):
    #     user = self.request.user
    #     queryset = User.objects.exclude(username=user.username)
    #     if distance := self.request.query_params.get('distance'):
    #         queryset = queryset.annotate(
    #             dis=ExpressionWrapper(
    #                 distance_1(
    #                     user.latitude,
    #                     F('latitude'),
    #                     user.longitude,
    #                     F('longitude')
    #                 ),
    #                 output_field=FloatField()
    #             )
    #         ).filter(dis__lt=float(distance))
    #     return queryset